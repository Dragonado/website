// SPDX-License-Identifier: MIT
//If you want to compile, you can install a working version of solc with 'solc-select'
pragma solidity 0.8.20;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";

/*
 ________  ___  ___  ________  ________  ________  ________  ___  ________
|\   __  \|\  \|\  \|\_____  \|\_____  \|\   ____\|\   __  \|\  \|\   ___  \
\ \  \|\ /\ \  \\\  \\|___/  /|\|___/  /\ \  \___|\ \  \|\  \ \  \ \  \\ \  \
 \ \   __  \ \  \\\  \   /  / /    /  / /\ \  \    \ \  \\\  \ \  \ \  \\ \  \
  \ \  \|\  \ \  \\\  \ /  /_/__  /  /_/__\ \  \____\ \  \\\  \ \  \ \  \\ \  \
   \ \_______\ \_______\\________\\________\ \_______\ \_______\ \__\ \__\\ \__\
    \|_______|\|_______|\|_______|\|_______|\|_______|\|_______|\|__|\|__| \|__|
*/

contract BuzzQuest {
    mapping (address => bool) private p1;
    mapping (address => bool) private p2;
    mapping (address => bool) private p3;
    mapping (address => bool) private p4;
    mapping (address => bool) private p5;

    mapping (address => bool) private perm;
    address owner;
    IERC20 public buzzToken;

    uint public mask;
    uint public logmask;

    modifier onlyOwner() {
        require(msg.sender == owner, "Not owner");
        _;
    }

    receive() external payable {}
    function donate() external payable {}

    constructor(address _buzzToken, address[] memory _users) {
        owner = msg.sender;
        buzzToken = IERC20(_buzzToken);

        for(uint i = 0; i < _users.length; i++){
            perm[_users[i]] = true;
        }
        mask = 1;
        logmask = 0;
    }

    function addUsers(address[] calldata _users) external onlyOwner {
        for (uint i = 0; i < _users.length; i++) {
            perm[_users[i]] = true;
        }
    }

    function removeUsers(address[] calldata _users) external onlyOwner {
        for (uint i = 0; i < _users.length; i++) {
            perm[_users[i]] = false;
        }
    }

    function problem1() external {
        require(!p1[msg.sender], "Already solved p1");
        require(perm[msg.sender], "Not permitted");
        buzzToken.transfer(msg.sender, 10 ether);
        p1[msg.sender] = true;
    }

    function problem2(uint nonce) external {
        require(!p2[msg.sender], "Already solved p2");
        require(perm[msg.sender], "Not permitted");
        uint256 hash = uint256(keccak256(abi.encode(nonce, msg.sender)));
        uint256 temp = hash % mask;
        if(temp == 0) {
            buzzToken.transfer(msg.sender, 30 ether);
            p2[msg.sender] = true;
            if(logmask < 34) {
                mask = mask << 1;
                logmask += 1;
            }
        }
    }

    mapping (address => uint) private last_block;
    function problem3() external {
        require(!p3[msg.sender], "Already solved p3");
        require(perm[msg.sender], "Not permitted");
        require(block.number != last_block[msg.sender], "Wait for next block");
        uint dice = uint(keccak256(abi.encode(msg.sender, block.number, block.timestamp))) % 6;
        last_block[msg.sender] = block.number;
        if(dice == 0){
            buzzToken.transfer(msg.sender, 10 ether);
            p3[msg.sender] = true;
        }
    }
    function problem4() external payable {
        require(!p4[msg.sender], "Already solved p4");
        require(perm[msg.sender], "Not permitted");
        require(msg.value == 3.14159265 ether, "Wrong value");
        buzzToken.transfer(msg.sender, 20 ether);
        p4[msg.sender] = true;
    }

    function problem5(uint nonce) external {
        require(!p5[msg.sender], "Already solved p5");
        require(perm[msg.sender], "Not permitted");
        uint256 hash = uint256(keccak256(abi.encode(nonce)));
        uint256 expected = 0x3aa605294d0b8f06632ee9423e3fbf9f67644137832a719c8db1c45bb925f894;
        if(hash == expected){
            buzzToken.transfer(msg.sender, 30 ether);
            p5[msg.sender] = true;
        }
    }
}
