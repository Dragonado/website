

 ________  ___  ___  ________  ________  ________  ________  ___  ________
|\   __  \|\  \|\  \|\_____  \|\_____  \|\   ____\|\   __  \|\  \|\   ___  \
\ \  \|\ /\ \  \\\  \\|___/  /|\|___/  /\ \  \___|\ \  \|\  \ \  \ \  \\ \  \
 \ \   __  \ \  \\\  \   /  / /    /  / /\ \  \    \ \  \\\  \ \  \ \  \\ \  \
  \ \  \|\  \ \  \\\  \ /  /_/__  /  /_/__\ \  \____\ \  \\\  \ \  \ \  \\ \  \
   \ \_______\ \_______\\________\\________\ \_______\ \_______\ \__\ \__\\ \__\
    \|_______|\|_______|\|_______|\|_______|\|_______|\|_______|\|__|\|__| \|__|


We have made our own cryptocurrency called Buzzcoin (BUZZ), an ERC-20 token deployed on the
Sepolia testnet. A contract (buzzcoin_2026.sol) has been deployed at a specified address
(buzzcoin_2026.address). The contract contains five functions, which will pay you
some BUZZ tokens. Your job is to make every function pay you. The number of
BUZZ tokens you can get is your grade.

Before you do anything. Take a good long look at the contract provided. Make
sure you understand what each question does before you attempt.

There is an easter egg somewhere. If you are the first to find it, you get 30
BUZZ. If you are the second, you get 15. The third gets 5. Send an email or a
private piazza post to claim your reward.

This is more important for the second part of the project (deployed later) where
whoever has the highest amount of buzzcoin by the end of the semester gets a
full letter grade bonus.

Finally, one of the questions may not feel the same depending on when you approach it. 
It’s worth keeping that in mind—starting earlier could make things a bit smoother ;)

If you want hints on any questions besides on setup, or problem1, you must pay
the tariff of two BUZZ token per hint. It may be worth it if my hint helps you get
twenty buzz, and I promise they will be good hints :) Transfer 1 BUZZ to

0xDF2892b4EA0cDbE9755C67943c15c79bDDd29bb6

And in your piazza post, send tx info of you paying me >:)

You are not allowed to try to attack the contract, or steal tokens
from other students. If you find an unlimited money glitch, let me know before
hand and we will give some bonus, instead of leaving no tokens for other
students.

Your deliverables are a list of all your transactions, your final BUZZ token balance (send a screenshot), and
a small writeup of how you solved each question. Enough for us to know you did
it

have fun!
